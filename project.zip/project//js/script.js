document.getElementById("Djojo_o").addEventListener('submit', function(event) {
        event.preventDefault(); //Mencegah form untuk submit secara default
    
        //Mendapatkan nilai username dan password
        var username = document.getElementById('username').value;
        var password = document.getElementById('password').value;
        var erormessage = document.getElementById('eror-message');
     
        //Validasi Username dan password
        if (username === '' || password === '') {
            erormessage.textContent = 'saskehh tidaa suka kosong sayangkuu!!';
        } else if (username !== 'Jojo' || password !=='123') {
            erorMessage.textContent = 'username atau password salah';
        } else {
            erorMessage.textContent = ''
            alert('anjayy berhasil!!');
        }
    });